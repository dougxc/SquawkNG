package com.sun.squawk.refactor;

import java.io.*;
import java.util.*;

/**
 * This is the driver class for the tool that changes invocations to 'assume' to
 * uses of the new 'assert' functionality of Java 1.4.
 */
public class Main {

    private Main() {
    }

    /**
     * Get the argument to a command line option. If the argument is not provided,
     * then a usage message is printed and the system exits.
     * @param args The command line arguments.
     * @param index The index at which the option's argument is located
     * @param opt The name of the option.
     * @return the options argument.
     */
    public static String getOptArg(String[] args, int index, String opt) {
        if (index >= args.length) {
            usage("The " + opt + " option requires an argument.");
            System.exit(1);
        }
        return args[index];
    }

    static void usage(String errMsg) {
        PrintStream out = System.out;
        if (errMsg != null) {
            out.println(errMsg);
        }
        out.println("Usage: refactorassert [-options] source_files...");
        out.println("where options include:");
        out.println("    -d <dir>           the output directory (default is to override input files)");
        out.println("    -from <name>       the name of the method whose invocations are to be");
        out.println("                       replaced with assert. Only invocations that take 1 or");
        out.println("                       2 parameters will be converted. Note: this tool doesn't");
        out.println("                       type check the parameters to assert.");
        out.println("    -comment           comment out the asserts");
        out.println("    -to <name>         the name of the method that will be used");
        out.println("                       to replace assert.");
        out.println();
        out.println("Note: exactly one of -from or -to must be supplied. Also, this tool ensures");
        out.println("      original files are not overridden.");
    }

    static String fixPath(String path) {
        if (File.separatorChar == '/') {
            return path.replace('\\', File.separatorChar);
        }
        else {
            return path.replace('/', File.separatorChar);
        }
    }

    static int[] getLineSizes(char[] data) {
        // count number of lines
        int num = 0;
        for (int i = 0; i != data.length; i++) {
            if (data[i] == '\n') {
                num++;
            }
        }
        // calculate line sizes
        int[] lineSizes = new int[num + 3];
        int line = 1;
        for (int i = 0; i < data.length; i++) {
            while (i < data.length && data[i] != '\n') {
                i++;
            }
            // add one for the newline
            assert line < lineSizes.length;
            lineSizes[line++] = i + 1;
        }
        return lineSizes;
    }

    public static void main (String [] args) {
        String outDir    = null;
        String from      = null;
        String to        = null;
        boolean comment  = false;

        // Parse options
        int i = 0;
        while (i != args.length) {
            if (args[i].charAt(0) != '-') {
                break;
            }
            String arg = args[i].intern();
            if (arg == "-d") {
                outDir = getOptArg(args, ++i, "-d");
            } else if (arg == "-from") {
                from = getOptArg(args, ++i, "-from");
            } else if (arg == "-comment") {
                comment = true;
            } else if (arg == "-to") {
                to = getOptArg(args, ++i, "-to");
            } else {
                usage("Bad switch "+arg);
                return;
            }
            i++;
        }

//        if (outDir == null) {
//            usage("Missing -d option");
//            return;
//        }

        if (i == args.length) {
            usage("Missing source files");
            return;
        }

        // Read source files
        Vector sources = new Vector();
        while (i != args.length) {
            sources.addElement(new JavaSourceFile(fixPath(args[i++])));
        }

        File baseDir = null;
        if (outDir != null) {
            baseDir = new File(fixPath(outDir));
            if (!(baseDir.isDirectory() && baseDir.canWrite())) {
                System.err.println(baseDir.getPath()+" is not a directory or cannot be written to");
                return;
            }
        }

        // Create and configure the parser
        RefactorAssert parser = new RefactorAssert(System.in);
        String openParen = null;
        String closeParen = null;
        String comma = null;
        if (from != null) {
            if (to == null) {
                parser.method = from;
                openParen = " ";
                closeParen = openParen;
                comma = ":";
                to = "assert";
            }
            else {
                usage("Exactly one of -from or -to must be supplied");
                return;
            }
        }
        else if (to != null) {
            if (from == null) {
                openParen = "(";
                closeParen = ")";
                comma = ",";
            }
            else {
                usage("Exactly one of -from or -to must be supplied");
                return;
            }
        }

        // Parse the source files...
        for (Enumeration e = sources.elements(); e.hasMoreElements();) {
            JavaSourceFile source = (JavaSourceFile)e.nextElement();
            try {
                System.out.print("parsing "+source.path+" ...");
                parser.source = source;
                parser.ReInit(new java.io.FileInputStream(source.path));
                parser.CompilationUnit();
                assert source.newPath != null;
                System.out.println(" done.");
            } catch (java.io.FileNotFoundException ex) {
                System.out.flush();
                ex.printStackTrace();
                return;
            } catch (ParseException ex) {
                System.out.flush();
                ex.printStackTrace();
                return;
            }
        }

        // Patch and re-write the source files...
        for (Enumeration e = sources.elements(); e.hasMoreElements();) {
            JavaSourceFile source = (JavaSourceFile)e.nextElement();
            try {
                char[] data = new char[(int)new File(source.path).length()];
                BufferedReader br = new BufferedReader(new FileReader(source.path));
                br.read(data);
                br.close();
                int[] lineSizes = getLineSizes(data);
                StringBuffer buf = new StringBuffer(data.length + (data.length / 2));
                int lastPos = 0;
                for (Enumeration invocations = source.invocations.elements(); invocations.hasMoreElements();) {
                    Invocation invoke = (Invocation)invocations.nextElement();
                    invoke.fixOffsets(lineSizes);
                    assert invoke.namePos.offset > lastPos;
                    assert invoke.openingPos.offset > 0;
                    assert invoke.closingPos.offset > 0;
                    assert invoke.closingPos.offset > invoke.openingPos.offset;
                    assert invoke.commaPos == null || (invoke.commaPos.offset > invoke.openingPos.offset && invoke.commaPos.offset < invoke.closingPos.offset);

                    // Append the stuff up to this invoke from the last invoke
                    buf.append(data, lastPos, (invoke.namePos.offset - lastPos));

                    // Append the comment open
                    if (comment) {
                        buf.append("/*");
                    }

                    // Append the assert keyword or method name
                    assert (new String(data, invoke.namePos.offset, invoke.name.length())).equals(invoke.name);
                    buf.append(to);

                    // Append the stuff between the old method name and the '('
                    int pos = invoke.namePos.offset + invoke.name.length();
                    if (pos != invoke.openingPos.offset) {
                        buf.append(data, pos, invoke.openingPos.offset - pos);
                    }

                    // Overwrite the '(' with a space (or vice versa)
                    buf.append(openParen);

                    pos = invoke.openingPos.offset + 1;
                    if (invoke.commaPos != null) {
                        // Append the stuff between the '(' and the ','
                        buf.append(data, pos, invoke.commaPos.offset - pos);
                        // Overwrite the ',' with a ':' (or vice versa)
                        buf.append(comma);
                        // Append the stuff between the ',' and the ')'
                        pos = invoke.commaPos.offset + 1;
                        buf.append(data, pos, invoke.closingPos.offset - pos);
                    }
                    else {
                        // Append the stuff between the '(' and the ')'
                        buf.append(data, pos, invoke.closingPos.offset - pos);
                    }

                    // Overwrite the ')' with a space (or vice versa)
                    buf.append(closeParen);

                    // Append the comment close
                    if (comment) {
                        buf.append("*/");
                    }

                    lastPos = invoke.closingPos.offset + 1;
                }

                // Append the stuff between the last ')' and the end of file
                buf.append(data, lastPos, data.length - lastPos);

                // Write the modified file
                File file = (baseDir == null ? new File(source.path) : new File(baseDir, source.newPath));
                file.getParentFile().mkdirs();
                FileWriter fw = new FileWriter(file);
//                if (new File(source.path).getCanonicalPath().equals(file.getCanonicalPath())) {
//                    throw new RuntimeException("Cannot overwrite original file: " + source.path);
//                }
                if (data.length < buf.length()) {
                    data = new char[buf.length()];
                }
                buf.getChars(0, buf.length(), data, 0);
                System.out.print("writing "+file.getPath()+" ...");
                fw.write(data, 0, buf.length());
                System.out.println(" done.");
                fw.close();

            } catch (IOException ex) {
                ex.printStackTrace();
                return;
            }
        }
    }

}

class JavaSourceFile {
    /** Path to original source file. */
    final String path;
    /** Fully qualified name of the top level public class. */
    String newPath;
    /** The invocations to migrate. */
    Vector invocations;

    JavaSourceFile(String path) {
        this.path        = path;
        this.invocations = new Vector();
    }
}

/**
 * This class represents an invocation to be replaced.
 */
class Invocation {

    Invocation(SourcePos openingPos, SourcePos closingPos, SourcePos commaPos) {
        this.openingPos = openingPos;
        this.closingPos = closingPos;
        this.commaPos   = commaPos;
    }

    Invocation() {}

    /** The name of the method being invoked. */
    String name;
    /** The offset to the invocation. */
    SourcePos namePos;
    /** The offset to the '(' of the invocation. */
    SourcePos openingPos;
    /** The offset to the ')' of the invocation. */
    SourcePos closingPos;
    /** The offset to the ',' of the invocation or null. */
    SourcePos commaPos;
    void fixOffsets(int[] lineSizes) {
        namePos.fixOffset(lineSizes);
        openingPos.fixOffset(lineSizes);
        closingPos.fixOffset(lineSizes);
        if (commaPos != null) {
            commaPos.fixOffset(lineSizes);
        }
    }
    public String toString() {
        return name+"@"+namePos+" '('@"+openingPos+(commaPos == null ? "" : " ','@"+commaPos)+" ')'@"+closingPos;
    }
}

class SourcePos {
    final int col;
    final int line;
    SourcePos(int col, int line) {
        this.col  = col;
        this.line = line;
    }
    void fixOffset(int[] lineSizes) {
        assert line != 0 && col != 0 && offset == -1;
        offset = 0;
        if (line > 1) {
            offset += lineSizes[line - 1];
        }
        offset += (col - 1);
    }
    int offset = -1;
    public String toString() {
        return "{line="+line+",col="+col+"}";
    }

}
